package musica;

public class Galinha extends Animal {
    private Animal anterior;

    public Galinha(Animal anterior) {
        super("galinha", "có");
        this.anterior = anterior;
    }

    public void cantar() {
        System.out.println("Lá em casa tinha uma " + getNome());
        System.out.println("Lá em casa tinha uma " + getNome());
        System.out.println("E a " + getNome() + " " + getSom());
        anterior.cantar();
    }
    public void cantarSom() {
        System.out.println("E o " + getNome() + " " + getSom());
    }
   }
