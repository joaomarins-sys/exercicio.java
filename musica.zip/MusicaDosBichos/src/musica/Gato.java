package musica;

public class Gato extends Animal {
    private Animal anterior;

    public Gato(Animal anterior) {
        super("gato", "miau");
        this.anterior = anterior;
    }

    public void cantar() {
        System.out.println("Lá em casa tinha um " + getNome());
        System.out.println("Lá em casa tinha um " + getNome());
        System.out.println("E o " + getNome() + " " + getSom());
        anterior.cantar();
    }
    public void cantarSom() {
        System.out.println("E o " + getNome() + " " + getSom());}
}
