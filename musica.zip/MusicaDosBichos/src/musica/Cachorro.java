package musica;

public class Cachorro extends Animal {
    private Animal anterior;

    public Cachorro(Animal anterior) {
        super("cachorro", "auau");
        this.anterior = anterior;
    }
    
    public void cantar() {
        System.out.println("Lá em casa tinha um " + getNome());
        System.out.println("Lá em casa tinha um " + getNome());
        System.out.println("E o " + getNome() + " " + getSom());
        anterior.cantar();
    }
    public void cantarSom() {
        System.out.println("E o " + getNome() + " " + getSom());

    }
}
