package musica;

public class Main {
    public static void main(String[] args) {
        Animal pintinho = new Pintinho();
        Animal galo = new Galo(pintinho);
        Animal galinha = new Galinha(galo);
        Animal cachorro = new Cachorro(galinha);
        Animal gato = new Gato(cachorro);

        pintinho.cantar();
        System.out.println();
        galo.cantar();
        System.out.println();
        galinha.cantar();
        System.out.println();
        cachorro.cantar();
        System.out.println();
        gato.cantar();
    }
}
