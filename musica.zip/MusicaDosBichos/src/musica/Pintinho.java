package musica;

public class Pintinho extends Animal {

    public Pintinho() {
        super("pintinho", "piu");
    }

    @Override
    public void cantar() {
        System.out.println("Lá em casa tinha um " + getNome());
        System.out.println("Lá em casa tinha um " + getNome());
        for (int i = 0; i < 6; i++) {
            cantarSom(); 
        }
    }

   
    public void cantarSom() {
        System.out.println("E o " + getNome() + " " + getSom());
    }
}
