package musica;

public class Galo extends Animal {
    private Animal anterior;

    public Galo(Animal anterior) {
        super("galo", "cocoricó");
        this.anterior = anterior;
    }

    
    public void cantar() {
        System.out.println("Lá em casa tinha um " + getNome());
        System.out.println("Lá em casa tinha um " + getNome());
        cantarSom();
        for (int i = 0; i < 5; i++) {
            anterior.cantarSom(); 
        }
    }


    public void cantarSom() {
        System.out.println("E o " + getNome() + " " + getSom());
    }
}
